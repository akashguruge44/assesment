-- Basic SQL schema (minimal). Import into MySQL if needed.
CREATE TABLE suppliers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  contact_person VARCHAR(255),
  phone VARCHAR(50),
  email VARCHAR(255),
  address TEXT,
  created_at TIMESTAMP NULL,
  updated_at TIMESTAMP NULL
);
-- Add other tables as needed (see migrations folder)
