<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\CylinderType;

class CylinderTypeSeeder extends Seeder
{
    public function run()
    {
        CylinderType::create(['name'=>'2.8kg','standard_price'=>200.00]);
        CylinderType::create(['name'=>'5kg','standard_price'=>350.00]);
        CylinderType::create(['name'=>'12.5kg','standard_price'=>1200.00]);
    }
}
