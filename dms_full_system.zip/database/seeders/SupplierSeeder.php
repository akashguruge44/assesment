<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\Supplier;

class SupplierSeeder extends Seeder
{
    public function run()
    {
        Supplier::create(['name'=>'ABC Gas Suppliers','contact_person'=>'Mr. A','phone'=>'0111234567','email'=>'abc@gas.lk']);
        Supplier::create(['name'=>'Global Gas','contact_person'=>'Ms. G','phone'=>'0117654321','email'=>'global@gas.lk']);
    }
}
