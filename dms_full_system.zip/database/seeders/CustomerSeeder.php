<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\Customer;

class CustomerSeeder extends Seeder
{
    public function run()
    {
        Customer::create(['type'=>'dealer','name'=>'Kandy Dealer','phone'=>'0810001111']);
        Customer::create(['type'=>'individual','name'=>'John Doe','phone'=>'0771234567']);
    }
}
