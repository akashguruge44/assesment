<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = ['order_number','customer_id','status','urgent','route_id','total'];
    public function items() { return $this->hasMany(OrderItem::class); }
}
