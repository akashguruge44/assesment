<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Grn extends Model
{
    protected $fillable = ['grn_number','supplier_id','purchase_order_id','received_at','remarks','status'];
    public function items() { return $this->hasMany(GrnItem::class); }
}
