<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class GrnItem extends Model
{
    protected $fillable = ['grn_id','cylinder_type_id','po_quantity','received_quantity','rejected_quantity'];
}
