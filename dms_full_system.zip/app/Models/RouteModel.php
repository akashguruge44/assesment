<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class RouteModel extends Model
{
    protected $table = 'routes';
    protected $fillable = ['name','driver','assistant'];
}
