<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PurchaseOrderItem extends Model
{
    protected $fillable = ['purchase_order_id','cylinder_type_id','quantity','unit_price','line_total'];
    public function cylinderType() { return $this->belongsTo(CylinderType::class); }
}
