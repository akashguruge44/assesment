<?php
namespace App\Http\Controllers;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index(){ $orders = Order::with('items')->get(); return view('orders.index', compact('orders')); }
    public function create(){ return view('orders.create'); }
    public function store(Request $r){ $data = $r->validate(['customer_id'=>'required','order_number'=>'required']); Order::create($data); return redirect()->route('orders.index'); }
}
