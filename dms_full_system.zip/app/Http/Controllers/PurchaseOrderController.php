<?php
namespace App\Http\Controllers;
use App\Models\PurchaseOrder;
use Illuminate\Http\Request;

class PurchaseOrderController extends Controller
{
    public function index() { $pos = PurchaseOrder::with('supplier')->get(); return view('purchase_orders.index', compact('pos')); }
    public function create() { return view('purchase_orders.create'); }
    public function store(Request $r) {
        // validate & store
        $data = $r->validate(['supplier_id'=>'required','po_number'=>'required']);
        $po = PurchaseOrder::create($data);
        return redirect()->route('purchase-orders.index')->with('success','PO created');
    }
    public function show(PurchaseOrder $purchaseOrder) { return view('purchase_orders.show', compact('purchaseOrder')); }
    public function edit(PurchaseOrder $purchaseOrder) { return view('purchase_orders.edit', compact('purchaseOrder')); }
    public function update(Request $r, PurchaseOrder $purchaseOrder) {
        $purchaseOrder->update($r->all());
        return redirect()->route('purchase-orders.index');
    }
    public function destroy(PurchaseOrder $purchaseOrder) {
        $purchaseOrder->delete();
        return redirect()->route('purchase-orders.index');
    }
}
