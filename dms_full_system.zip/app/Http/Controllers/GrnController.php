<?php
namespace App\Http\Controllers;
use App\Models\Grn;
use Illuminate\Http\Request;

class GrnController extends Controller
{
    public function index() { $grns = Grn::with('items')->get(); return view('grns.index', compact('grns')); }
    public function create() { return view('grns.create'); }
    public function store(Request $r) {
        $data = $r->validate(['supplier_id'=>'required','grn_number'=>'required']);
        $grn = Grn::create($data);
        return redirect()->route('grns.index');
    }
}
